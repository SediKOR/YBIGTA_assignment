def print1() :
    print('와~~~ 첫 번째 과제다~~~')